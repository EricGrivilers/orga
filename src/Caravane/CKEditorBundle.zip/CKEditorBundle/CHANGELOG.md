# CHANGELOG

### 1.1.1 - 2.1.1 (2013-01-27)

 * e0b086a - Allow to configure ckeditor form type through configuration
 * 038d7c1 - Upgrade CKEditor to 4.0.1
 * b90ea78 - Fix assets_version support
 * 4be2e56 - Add support for assets_version
 * e787087 - [Widget] Remove autoescape js

### 1.1.0 - 2.1.0 (2013-01-12)

 * fd79848 - [Form][Type] Allow to set all config options.

### 1.0.0 - 2.0.0 (2013-01-12)
