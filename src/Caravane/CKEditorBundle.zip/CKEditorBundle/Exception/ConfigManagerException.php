<?php

/*
 * This file is part of the Ivory CKEditor package.
 *
 * (c) Eric GELOEN <geloen.eric@gmail.com>
 *
 * For the full copyright and license information, please read the LICENSE
 * file that was distributed with this source code.
 */

namespace Caravane\CKEditorBundle\Exception;

/**
 * Config manager exception.
 *
 * @author GeLo <geloen.eric@gmail.com>
 */
class ConfigManagerException extends Exception
{
    /**
     * Gets the "CONFIG DOES NOT EXIST" exception.
     *
     * @param string $name The invalid CKEditor config name.
     *
     * @return \Caravane\CKEditorBundle\Exception\ConfigManagerException The "CONFIG DOES NOT EXIST" exception.
     */
    static public function configDoesNotExist($name)
    {
        return new static(sprintf('The CKEditor config "%s" does not exist.', $name));
    }
}
