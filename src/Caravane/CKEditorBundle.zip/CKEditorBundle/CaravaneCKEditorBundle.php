<?php

namespace Caravane\CKEditorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CaravaneCKEditorBundle extends Bundle
{
}
